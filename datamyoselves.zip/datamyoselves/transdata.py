import numpy as np
import pandas as pd
import os
from collections import defaultdict

def single_csv_to_npy(csv_file_path, output_npy_path, use_pandas=True):
    """
    单个CSV文件转换为NPY文件，并剔除第一列（时间戳）。
    :param csv_file_path: 输入单个CSV文件路径
    :param output_npy_path: 输出单个NPY文件路径
    :param use_pandas: 是否使用pandas读取（兼容性更强，推荐）
    """
    try:
        if use_pandas:
            # 使用pandas读取CSV，它会自动处理表头
            csv_data = pd.read_csv(csv_file_path)
            # 使用 .iloc[:, 1:] 剔除第一列（时间列），然后转换为NumPy数组
            # 结果形状将是 (n_samples, 8)
            npy_data = csv_data.iloc[:, 1:].to_numpy()
        else:
            # 使用numpy直接读取，需要手动跳过表头
            # genfromtxt会自动处理逗号分隔符
            npy_data = np.genfromtxt(csv_file_path, delimiter=',', skip_header=1)
            # 使用 [:, 1:] 剔除第一列（时间列）
            npy_data = npy_data[:, 1:]
        
        # 确保输出目录存在
        output_dir = os.path.dirname(output_npy_path)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        
        # 保存NPY文件
        np.save(output_npy_path, npy_data)
        print(f"✅ 成功转换：{csv_file_path} -> {output_npy_path}")
        print(f"   数据形状：{npy_data.shape} | 数据类型：{npy_data.dtype}")
    except FileNotFoundError:
        print(f"❌ 错误：未找到文件 {csv_file_path}")
    except Exception as e:
        print(f"❌ 转换失败 {csv_file_path}：{str(e)}")

def batch_csv_to_npy_custom(root_input_dir, root_output_dir):
    """
    批量转换：将CSV文件转换后放入一个输出目录，并按“人名+手势名.序号”格式重命名。
    :param root_input_dir: 输入根文件夹路径 (例如: ".../traindata/张德")
    :param root_output_dir: 输出根文件夹路径
    """
    # 1. 从输入根目录路径中提取人名
    person_name = os.path.basename(os.path.normpath(root_input_dir))
    if not person_name:
        print("❌ 错误：无法从输入路径中提取人名。请检查路径格式。")
        return

    # 确保输出根目录存在
    if not os.path.exists(root_output_dir):
        os.makedirs(root_output_dir, exist_ok=True)

    # 2. 使用字典来为每个手势类别独立计数
    gesture_counter = defaultdict(int)

    print(f"🚀 开始批量转换，提取的人名: '{person_name}'")

    # 遍历输入根文件夹下的所有文件（递归）
    for root, dirs, files in os.walk(root_input_dir):
        for file_name in files:
            if file_name.lower().endswith('.csv'):
                input_csv_full_path = os.path.join(root, file_name)
                
                # 3. 从当前文件所在的文件夹路径中提取手势名
                gesture_name = os.path.basename(os.path.normpath(root))
                
                # 4. 为当前手势增加计数
                gesture_counter[gesture_name] += 1
                current_index = gesture_counter[gesture_name]
                
                # 5. 按照 "人名手势名.序号" 的格式构建新的NPY文件名
                new_file_name = f"{person_name}{gesture_name}.{current_index}.npy"
                
                # 6. 构建最终的输出文件完整路径
                output_npy_full_path = os.path.join(root_output_dir, new_file_name)
                
                # 7. 执行单个文件转换
                single_csv_to_npy(input_csv_full_path, output_npy_full_path)

# ------------------- 调用示例 -------------------
if __name__ == "__main__":
    # *************************
    # 请修改为你的实际路径！！！
    # *************************
    # 输入根文件夹：路径的最后一部分应为人名
    ROOT_INPUT_DIR = "C:\\Users\\18434\\Desktop\\论文\\Myo-Collection-master\\traindata\\张德"
    # 输出根文件夹：所有格式化后的NPY文件将直接放在这里
    ROOT_OUTPUT_DIR = "张德_npy_final"  # 建议使用新的输出目录名
    
    if not os.path.exists(ROOT_INPUT_DIR):
        print(f"❌ 错误：输入根目录 {ROOT_INPUT_DIR} 不存在，请检查路径！")
    else:
        print(f"📁 输入目录：{ROOT_INPUT_DIR}")
        print(f"📁 输出目录：{ROOT_OUTPUT_DIR}")
        # 调用修改后的自定义转换函数
        batch_csv_to_npy_custom(ROOT_INPUT_DIR, ROOT_OUTPUT_DIR)
        print("\n🎉 批量转换任务执行完毕！")